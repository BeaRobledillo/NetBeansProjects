/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package almacen_dao_mvc;

/**
 *
 * @author teide
 */
public class Almacen_DAO_MVC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //1. Creamos un prodcuto nuevo y lo insertamos
        //2. Listamos un cliente
        //3. Modificamos un cliente
        //4. Borramos un cliente
    }
    
}
