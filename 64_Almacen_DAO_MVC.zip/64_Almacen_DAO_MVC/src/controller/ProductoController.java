package controller;

import dao.ProductoDAOImpl;
import idao.iProductoDAO;
import view.ProductoVista;

public class ProductoController {

    
    /*Debemos tener como atributos una instancia de la vista y una instancia de DAOImpl*/
    private  ProductoVista vista;
    private iProductoDAO dao;
}
